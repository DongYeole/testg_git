/**
 * 
 */
 function wish(){
 	let wish_btn = document.getElementById("wish_btn");
 	wish_btn.innerHTML = "";
 	
 	alert("찜 목록에 상품이 추가되었습니다.");
 }
 
 // 상품 대표 이미지 전환
 
 function prev(){
 	
 }