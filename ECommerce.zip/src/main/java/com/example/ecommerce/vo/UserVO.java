package com.example.ecommerce.vo;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserVO {

	@Getter @Setter
	int id;

	@Getter @Setter
	String username, password, name, phone, email, reset_token;

	@Getter @Setter
	Date reset_token_expires_at, deleted_at, created_at;
}
