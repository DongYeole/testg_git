package com.example.ecommerce;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.ecommerce.vo.ReviewVO;

import common.Common;
import dto.ReviewDTO;

@Controller
public class ReviewController {
	
	// @Autowired
	@Autowired
	HttpServletRequest request;
	
	// DAO
	@Autowired
	ReviewDTO rev_dto;
	
	// 해당 상품의 리뷰 목록 조회
	@RequestMapping("/review.do")
	public String reviewPage( Model model, int pro_id ) {
		ReviewVO rev_pro = rev_dto.selOneReview(pro_id);
		model.addAttribute("rev_pro", rev_pro);
		return Common.home.VIEW_PATH + "productReviewPage.jsp";
	}

}
