package com.example.ecommerce;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.ecommerce.vo.ProductVO;
import com.example.ecommerce.vo.ReviewVO;

import common.Common;
import dto.ProductDTO;

@Controller
public class ProductController {
	
	// @Autowired
	@Autowired
	HttpServletRequest request;
	
	// setter
	@Autowired
	private ProductDTO pro_dto;
	
	// @RRequestMapping
	
	// 홈 화면
	@RequestMapping( value = { "/", "/home.do" } )
	public String homePage() {
		return Common.home.VIEW_PATH + "home.jsp";
	}
	
	// 상품 등록 폼으로 이동
	@RequestMapping("/pro_regist_form.do")
	public String registForm() {
		return Common.product.VIEW_PATH + "productRegistPage.jsp";
	}
	
	
	// 상품 상세보기
	@RequestMapping("/pro_detail_view.do")
	public String detailView( Model model, int id) {
		ProductVO pro_vo = pro_dto.selectOne(id);
		model.addAttribute("pro_vo", pro_vo);
		
		return Common.product.VIEW_PATH + "productDetailPage.jsp";
	}
	
	

}












