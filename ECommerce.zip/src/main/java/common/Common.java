package common;

public class Common {
	
	public static class product{
		public static final String VIEW_PATH = "/WEB-INF/views/product/";
	}
	
	public static class home{
		public static final String VIEW_PATH = "/WEB-INF/views/";
	}
	
	

}
