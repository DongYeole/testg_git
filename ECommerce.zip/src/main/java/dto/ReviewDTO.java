package dto;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.ecommerce.vo.ReviewVO;

@Repository
public class ReviewDTO {
	
	@Autowired
	SqlSession sqlSession;
	
	// 리뷰 목록 조회
	public ReviewVO selOneReview( int pro_id ) {
		ReviewVO vo = sqlSession.selectOne("re.review_list", pro_id);
		return vo;
	}

}
