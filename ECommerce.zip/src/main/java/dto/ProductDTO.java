package dto;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.ecommerce.vo.ProductVO;
import com.example.ecommerce.vo.ReviewVO;

@Repository
public class ProductDTO {
	
	// setter
	@Autowired
	SqlSession sqlSession;
	
	// 메서드

	
	// 해당 상품 상세보기 페이지(id)
	public ProductVO selectOne( int id ) {
		ProductVO vo = sqlSession.selectOne("pro.pro_detail_view", id);
		return vo;
	}
	

	
	
}
